# Installation

It's best to install [PHRETS](https://packagist.org/packages/troydavisson/PHRETS) using [Composer](http://getcomposer.org):

    composer require troydavisson/phrets



# Basic Requirements

* PHP 5.6+
* Installed via [Composer](http://getcomposer.org)


# Other Requirements

* [Default timezone set](http://php.net/date_default_timezone_set) in PHP
