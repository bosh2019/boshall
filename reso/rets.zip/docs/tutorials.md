
# Video Tutorials

### New Features in 2.0
[![New Features in 2.0](http://img.youtube.com/vi/115mx-9jYVM/0.jpg)](http://www.youtube.com/watch?v=115mx-9jYVM)

### Authentication and Connection
[![Authentication and Connecting](http://img.youtube.com/vi/AqC0eUohVVk/0.jpg)](http://www.youtube.com/watch?v=AqC0eUohVVk)

### Making a First Connection
[![Making a First Connection](http://img.youtube.com/vi/c8lpa7IOrlw/0.jpg)](http://www.youtube.com/watch?v=c8lpa7IOrlw)

### Debugging / Logging
[![Logging](http://img.youtube.com/vi/9MPJwsLtG70/0.jpg)](http://www.youtube.com/watch?v=9MPJwsLtG70)

> If you know of a guide or tutorial you feel would be appropriate to include here, please [add it](contribute/)
