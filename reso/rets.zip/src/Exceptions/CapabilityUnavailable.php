<?php namespace PHRETS\Exceptions;

class CapabilityUnavailable extends \Exception
{

}
