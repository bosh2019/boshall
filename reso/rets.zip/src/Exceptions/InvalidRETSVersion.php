<?php namespace PHRETS\Exceptions;

class InvalidRETSVersion extends \Exception
{

}
