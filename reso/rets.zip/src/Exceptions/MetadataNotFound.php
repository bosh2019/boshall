<?php namespace PHRETS\Exceptions;

class MetadataNotFound extends \Exception
{

}
